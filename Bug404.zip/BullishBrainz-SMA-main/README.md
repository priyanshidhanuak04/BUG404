SOME PART OF THIS CODE HAS BEEN WRITTEN FOR THE XTS SERVER WHICH IS USED FOR BACKTESTING THE CODE ON PREVIOUS YEAR DATA , CERTAIN FUNCTIONS LIKE QUERY FUNCTION ( IS USED TO FETCH THE FUTURE AND OPTION DATA FROM THE SERVER ) AND THE GET_EXPIRY FUNCTION IS ALSO USED TO GET THE EXPIRY DATE

INITIAL CONDITIONS :
Take 5 minute candle 
Calculate 10 SMA and 30 SMA
     FOR Selling Call and exiting PUT
If SMA 10 > SMA 30 
CLOSE > SMA 10 
WHEN THE NEXT CANDLE BREAKS THE HIGH OF THE  CURRENT CANDLE 
CALL BUY , PUT EXIT( IF POSITION IS OPEN )
      FOR Selling Put and Exiting Call
IF SMA 10 < SMA 30 
CLOSE < SMA 10 
WHEN THE NEXT CANDLE BREAKS THE LOW OF THE  CURRENT CANDLE
PUT BUY , CALL EXIT ( IF POSITION IS OPEN ) conditions in the future data 

Python - for its versatility and extensive libraries for data analysis and trading automation.
Numpy - for handling large arrays and doing complex mathematical operations
Pandas - for handling structured data like time series and tables, and analyzing structured financial data.
Plotly / Matplotlib –for creating static charts or interactive graphs for visualising price trends, volume, and other key metrics in trading
Streamlit – for displaying data in the form of interactive web applications
Y finance – for accessing historical market data 
Talib - For computing various technical indicators commonly used in trading strategies, such as moving averages,
